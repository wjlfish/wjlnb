<?php if(isset($art['pic'])){?>
                <img src="<?php echo $art['pic'];?>" alt="">
                <?php }?>