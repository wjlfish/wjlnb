<!--enctype属性标识提交表单时要用哪种内容类型，我们这是上传文件（二进制数据），使用multipart/form-data-->
2 <form action="upload_img.php" method="post" enctype="multipart/form-data">
3     <input type="file" name="file" id="file"/>
4     <input type="submit" value="Submit"/>
5 </form>