<?php
$urls = array(
    'https://account.wjlnb.com',
);
$api = 'http://data.zz.baidu.com/urls?site=www.wjlnb.com&token=argb8VcDDtE23Jvb';
$ch = curl_init();
$options =  array(
    CURLOPT_URL => $api,
    CURLOPT_POST => true,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POSTFIELDS => implode("\n", $urls),
    CURLOPT_HTTPHEADER => array('Content-Type: text/plain'),
);
curl_setopt_array($ch, $options);
$result = curl_exec($ch);

ini_set('session.cookie_path', '/');
ini_set('session.cookie_domain', '.wjlnb.com');
ini_set('session.cookie_lifetime', '1800');
session_start();
if(!isset($_SESSION['userid'])){
	header("Location:login");
	exit();
}

$picsrc = $_SESSION['picsrc'];	
$userid = $_SESSION['userid'];
$username = $_SESSION['username'];
$regtime = $_SESSION['regtime'];
$rltime = date("Y-m-d H:i:s", $regtime);
$email = $_SESSION['email'];
function OutputTitle(){
    echo '。。。出错了';
}
?>
<!DOCTYPE html>
<head>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?3a3a1bd7259a0b6945b58736c271a902";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<script type="text/javascript">
function myFunction(){
	alert('会员系统目前已经开始公测，若您在这里发现了任何bug，请与我联系，谢谢。');
}
</script>
<script>
var _hmt = _hmt || [];
(function() {
  var hm = document.createElement("script");
  hm.src = "https://hm.baidu.com/hm.js?3a3a1bd7259a0b6945b58736c271a902";
  var s = document.getElementsByTagName("script")[0]; 
  s.parentNode.insertBefore(hm, s);
})();
</script>
<script>
(function(){
    var bp = document.createElement('script');
    var curProtocol = window.location.protocol.split(':')[0];
    if (curProtocol === 'https') {
        bp.src = 'https://zz.bdstatic.com/linksubmit/push.js';
    }
    else {
        bp.src = 'http://push.zhanzhang.baidu.com/push.js';
    }
    var s = document.getElementsByTagName("script")[0];
    s.parentNode.insertBefore(bp, s);
})();
</script>
<script type="text/javascript">
            /*
              进入页面加载的方法
            */
            window.onload=function()
            {
                 var date=new Date(),time=date.getTime();
                 setInterval(function() {set(time);time = Number(time);time += 1000;},1000);
                 setTodayDate(date);
            }
          
          /*
           设置日期的方法，针对年月日星期的显示
          */
          function setTodayDate(today)
          {
              var years,months,dates,weeks, intYears,intMonths,intDates,intWeeks,today,timeString;
              
              intYears = today.getFullYear();//获得年
              intMonths = today.getMonth() + 1;//获得月份+1
              intDates = today.getDate();//获得天数
              intWeeks = today.getDay();//获得星期
              
              years = intYears + '年';
              
              if(intMonths < 10){
                  months = '0' + intMonths + '月';
              }else{
                  months = intMonths + '月';
              }
              
              if(intDates < 10){
                  dates = '0' + intDates + '日     ';
              }else{
                  dates = intDates + '日     ';
              }
              
              var weekArray = new Array(7);
              weekArray[0] = '星期日';
              weekArray[1] = '星期一';
              weekArray[2] = '星期二';
              weekArray[3] = '星期三';
              weekArray[4] = '星期四';
              weekArray[5] = '星期五';
              weekArray[6] = '星期六';
              weeks =weekArray[intWeeks] + ' ';
    
              timeString = years + months + dates + weeks;
              
              document.getElementById('time').innerHTML=timeString;
           }
    
         /*
           设置北京时间的方法，针对时分秒的显示
         */
         function set(time)
         {
             var beijingTimeZone = 8;
             var timeOffset = ((-1 * (new Date()).getTimezoneOffset()) - (beijingTimeZone * 60)) * 60000;
             var now = new Date(time - timeOffset);
             document.getElementById('bjtime').innerHTML = p(now.getHours())+':'+p(now.getMinutes())+':'+p(now.getSeconds());
         }
         
         /*
           格式化时间的显示方式
         */
         function p(s) 
         {
            return s < 10 ? '0' + s : s;
         }
    
         </script>
<style>
       #bg{
            background: linear-gradient(45deg, #0099FF,#9999FF,#3300FF,#FF00FF);
            height: 100%;
        }
</style>
<link rel="stylesheet" type="text/css" href="css/index.css">
<link rel="stylesheet" type="text/css" href="css/reset.css">
<link rel="icon" href="https://www.wjlnb.com/img/favicon.ico" sizes="32x32">
<script src="https://cdn.staticfile.org/jquery/1.11.1/jquery.js"></script>
<style type="text/css">
<!--
body{ color:#000; font:12px Arial, Helvetica, sans-serif;}
#aa{ color:#000; text-decoration:none;}
#divcon{ background:#eee; padding:10px; width:150px;}
-->
</style>

        <meta charset="utf8">

        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">

  	 <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Material Design for Bootstrap fonts and icons -->
  <!-- <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700|Material+Icons"> -->

  <!-- Material Design for Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap-material-design.min.css">
  <link rel="stylesheet" href="css/common.css">
  <link rel="stylesheet" href="css/toastify.min.css">
  
  <title>个人中心——空中课堂导航</title>

                                

                                <style type="text/css">

                                body,td,th {
	font-family: Kanit, sans-serif;
	text-align: center;
}

                                </style>

        <link rel="stylesheet" href="https://www.wjlnb.com/css/bootstrap.min.css">

        <link rel="stylesheet" href="https://www.wjlnb.com/css/bootstrap-theme.min.css">

        <link rel="stylesheet" href="https://www.wjlnb.com/css/fontAwesome.css">

        <link rel="stylesheet" href="https://www.wjlnb.com/css/light-box.css">

        <link rel="stylesheet" href="https://www.wjlnb.com/css/templatemo-style.css">



        <link href="https://fonts.googleapis.com/css?family=Kanit:100,200,300,400,500,600,700,800,900" rel="stylesheet">



        <script src="js/vendor/modernizr-2.8.3-respond-1.4.2.min.js"></script>
</head>

<body>
<div id="bg">

    <nav>
        <div class="logo">
            <a href="https://www.wjlnb.com">空中课堂导航-主站</a><form action="uploadfile/upload_img.php" method="post" enctype="multipart/form-data">
    <input type="file" name="file" id="file"/>
     <input type="submit" value="上传你的头像"/>
</form>
        </div>
    </nav>

    <div id="video-container">
        <div class="video-content">
            <div class="inner">
<!--enctype属性标识提交表单时要用哪种内容类型，我们这是上传文件（二进制数据），使用multipart/form-data-->

            <p><?php 
echo"<img src='".$picsrc."'><br>";
echo '个人信息<br />';
echo '<a id="time"></a><br />';
echo '<a id="bjtime"></a><br />';
echo '---------------------------------<br />';
echo '您是本网站第',$userid,'个注册的人<br />';
echo '您的用户名是：<br />';
echo '',$username,'<br />';
echo '您的注册邮箱是：<br />';
echo '',$email,'<br />';
echo '您的注册时间是：<br />';
echo '',$rltime,'<br />';
echo '会员有效期至：<br />';
echo '2020-12-31 24:00:00<br />';
if($_SESSION['username'] == "admin" or "王嘉麟" && $_SESSION['userid'] =="1" or "6")
	echo '用户组：<a href="admin">超级管理员</a>';
else
 echo '用户组：普通用户';
echo '<br />';
echo '<a href="logindo.php?action=logout">注销</a><br />';
echo '<a href="https://www.wjlnb.com">前往主页</a><br />';
?>
            </div>
        </div>
    </div>
                  
    <footer>
        <div class="container-fluid">
            <div class="col-md-12">
                <p>COPYRIGHT © 2020 <a href="https://wjlnb.com">wjlnb.com</a> <a href="admin">管理系统</a></p>
    
            </div>
        </div>
    </footer>




   

    <script src="https://cdn.bootcss.com/jquery/1.11.2/jquery.min.js"></script>
    <script>window.jQuery || document.write('<script src="https://www.wjlnb.com/js/vendor/jquery-1.11.2.min.js"><\/script>')</script>

    <script src="https://www.wjlnb.com/js/vendor/bootstrap.min.js"></script>
    
    <script src="https://www.wjlnb.com/js/plugins.js"></script>
    <script src="https://www.wjlnb.com/js/main.js"></script>

 </html>
